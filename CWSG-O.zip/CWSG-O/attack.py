from __future__ import annotations
import argparse
import json
from dataclasses import asdict
from pathlib import Path
import torch
import torch.nn as nn
from torchvision import transforms
from cwsg import CWSGConfig, cwsg_attack
from cwsg.segmentation import get_primary_foreground_mask
from cwsg.utils import load_image, save_comparison, save_heatmap, save_tensor_image, set_seed


def _build_victim(name: str, device: torch.device) -> nn.Module:
    name = name.lower()
    if name == 'resnet50':
        return torchvision.models.resnet50(weights='IMAGENET1K_V1').to(device).eval()
    if name == 'vgg16':
        return torchvision.models.vgg16(weights='IMAGENET1K_V1').to(device).eval()
    if name == 'vit_b_16':
        return torchvision.models.vit_b_16(weights='IMAGENET1K_V1').to(device).eval()
    raise ValueError(f"Unsupported victim '{name}'. Choose from resnet50, vgg16, vit_b_16.")


@torch.no_grad()
def predict_with_victim(img: torch.Tensor, model_name: str, device: torch.device) -> Tuple[int, float]:
    model = _build_victim(model_name, device)
    normalize = transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
    logits = model(normalize(img).unsqueeze(0))
    prob = torch.softmax(logits, dim=1)
    conf, pred = prob.max(dim=1)
    return (int(pred.item()), float(conf.item()))


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description='CWSG black-box adversarial attack')
    parser.add_argument('--img', type=str, required=True, help='Path to the source image')
    parser.add_argument('--target_img', type=str, required=True, help='Path to the guidance image')
    parser.add_argument('--out_dir', type=str, default='cwsg_outputs')
    parser.add_argument('--img_size', type=int, default=224)
    parser.add_argument('--patch_size', type=int, default=8)
    parser.add_argument('--stride', type=int, default=4)
    parser.add_argument('--steps', type=int, default=20)
    parser.add_argument('--eps', type=float, default=8.0 / 255.0)
    parser.add_argument('--eta', type=float, default=0.1)
    parser.add_argument('--gamma', type=float, default=1.0)
    parser.add_argument('--tv_lambda', type=float, default=0.2)
    parser.add_argument('--filter_order', type=int, default=2)
    parser.add_argument('--rho', type=float, default=0.3)
    parser.add_argument('--background_weight', type=float, default=0.2)
    parser.add_argument('--mask_patch_threshold', type=float, default=0.4)
    parser.add_argument('--detector_conf', type=float, default=0.5)
    parser.add_argument('--mask_bin_threshold', type=float, default=0.5)
    parser.add_argument('--hue_weight', type=float, default=0.2)
    parser.add_argument('--style_weight', type=float, default=0.3)
    parser.add_argument('--freq_weight', type=float, default=0.5)
    parser.add_argument('--approx_centrality_k', type=int, default=None)
    parser.add_argument('--seed', type=int, default=42)
    parser.add_argument('--quiet', action='store_true')
    parser.add_argument('--evaluate', action='store_true', help='Evaluate optional torchvision victims')
    parser.add_argument('--victims', type=str, nargs='*', default=['resnet50', 'vgg16'], choices=['resnet50', 'vgg16', 'vit_b_16'])
    return parser.parse_args()


def config_from_args(args: argparse.Namespace) -> CWSGConfig:
    return CWSGConfig(patch_size=args.patch_size, stride=args.stride, steps=args.steps, eps=args.eps, eta=args.eta, gamma=args.gamma, tv_lambda=args.tv_lambda, filter_order=args.filter_order, rho=args.rho, background_weight=args.background_weight, mask_patch_threshold=args.mask_patch_threshold, hue_weight=args.hue_weight, style_weight=args.style_weight, freq_weight=args.freq_weight, approx_centrality_k=args.approx_centrality_k, seed=args.seed)


def main() -> None:
    args = parse_args()
    set_seed(args.seed)
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    print(f'Device: {device}')
    print(f'Output directory: {out_dir}')
    img = load_image(args.img, args.img_size, device)
    target_img = load_image(args.target_img, args.img_size, device)
    mask_ori = get_primary_foreground_mask(img, device, args.detector_conf, args.mask_bin_threshold)
    mask_tar = get_primary_foreground_mask(target_img, device, args.detector_conf, args.mask_bin_threshold)
    cfg = config_from_args(args)
    adv_img, perturbations, traces, graph = cwsg_attack(img=img, target_img=target_img, mask_ori=mask_ori, mask_tar=mask_tar, cfg=cfg, device=device, img_size=args.img_size, verbose=not args.quiet)
    save_tensor_image(img, out_dir / 'source.png')
    save_tensor_image(target_img, out_dir / 'guidance.png')
    save_tensor_image(adv_img, out_dir / 'cwsg_adv.png')
    save_comparison([img, target_img, adv_img], ['Source', 'Guidance', 'CWSG adversarial'], out_dir / 'comparison.png')
    save_heatmap(mask_ori.cpu().numpy().astype(np.float32), 'Source foreground mask', out_dir / 'source_mask.png')
    save_heatmap(mask_tar.cpu().numpy().astype(np.float32), 'Guidance foreground mask', out_dir / 'guidance_mask.png')
    for name in ('H', 'S', 'V'):
        save_heatmap(perturbations[name].abs().cpu().numpy(), f'{name}-channel perturbation', out_dir / f'perturbation_{name}.png')
    with open(out_dir / 'loss_trace.json', 'w', encoding='utf-8') as f:
        json.dump({'config': asdict(cfg), 'traces': traces}, f, indent=2)
    with open(out_dir / 'graph_summary.json', 'w', encoding='utf-8') as f:
        json.dump({'nodes': graph.n_nodes, 'edges': int(graph.edge_index_unique.shape[1]), 'key_nodes': int((graph.m == 1.0).sum().item()), 'rho': cfg.rho, 'patch_size': cfg.patch_size, 'stride': cfg.stride}, f, indent=2)
    if args.evaluate:
        print('\nVictim predictions:')
        for victim in args.victims:
            clean_pred, clean_conf = predict_with_victim(img, victim, device)
            adv_pred, adv_conf = predict_with_victim(adv_img, victim, device)
            print(f'  {victim}: clean={clean_pred} ({clean_conf:.4f}) -> adv={adv_pred} ({adv_conf:.4f})')
    print(f'\nSaved adversarial image and diagnostics to: {out_dir}')

if __name__ == "__main__":
    main()
