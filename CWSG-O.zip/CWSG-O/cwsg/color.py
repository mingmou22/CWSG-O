from __future__ import annotations
import torch
from typing import Sequence


def rgb_to_hsv(img: torch.Tensor, eps: float=1e-08) -> torch.Tensor:
    r, g, b = (img[0], img[1], img[2])
    maxc = torch.maximum(torch.maximum(r, g), b)
    minc = torch.minimum(torch.minimum(r, g), b)
    chroma = maxc - minc
    safe_chroma = chroma.clamp_min(eps)
    rc = (maxc - r) / safe_chroma
    gc = (maxc - g) / safe_chroma
    bc = (maxc - b) / safe_chroma
    h = torch.where(maxc == r, bc - gc, torch.where(maxc == g, 2.0 + rc - bc, 4.0 + gc - rc))
    h = (h / 6.0).remainder(1.0)
    h = torch.where(chroma <= eps, torch.zeros_like(h), h)
    s = torch.where(maxc <= eps, torch.zeros_like(maxc), chroma / maxc.clamp_min(eps))
    v = maxc
    return torch.stack([h, s, v], dim=0)


def _hsv_channel_select(i: torch.Tensor, values: Sequence[torch.Tensor]) -> torch.Tensor:
    out = values[-1]
    for k in range(len(values) - 2, -1, -1):
        out = torch.where(i == k, values[k], out)
    return out


def hsv_to_rgb(hsv: torch.Tensor) -> torch.Tensor:
    h, s, v = (hsv[0].remainder(1.0), hsv[1].clamp(0, 1), hsv[2].clamp(0, 1))
    h6 = h * 6.0
    i_float = torch.floor(h6)
    f = h6 - i_float
    i = i_float.to(torch.int64).remainder(6)
    p = v * (1.0 - s)
    q = v * (1.0 - f * s)
    t = v * (1.0 - (1.0 - f) * s)
    r = _hsv_channel_select(i, [v, q, p, p, t, v])
    g = _hsv_channel_select(i, [t, v, v, q, p, p])
    b = _hsv_channel_select(i, [p, p, t, v, v, q])
    return torch.stack([r, g, b], dim=0).clamp(0, 1)


def project_nodes(x: torch.Tensor, x_ori: torch.Tensor, eps: float, channel: str) -> torch.Tensor:
    delta = x - x_ori
    if channel == 'H':
        delta = (delta + 0.5).remainder(1.0) - 0.5
        delta = delta.clamp(-eps, eps)
        return (x_ori + delta).remainder(1.0)
    delta = delta.clamp(-eps, eps)
    return (x_ori + delta).clamp(0.0, 1.0)
