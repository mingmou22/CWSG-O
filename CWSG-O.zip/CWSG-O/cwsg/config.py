from __future__ import annotations
from dataclasses import dataclass
from typing import Optional


@dataclass
class CWSGConfig:
    patch_size: int = 8
    stride: int = 4
    steps: int = 20
    eps: float = 8.0 / 255.0
    eta: float = 0.1
    gamma: float = 1.0
    tv_lambda: float = 0.2
    filter_order: int = 2
    rho: float = 0.3
    background_weight: float = 0.2
    mask_patch_threshold: float = 0.4
    hue_weight: float = 0.2
    style_weight: float = 0.3
    freq_weight: float = 0.5
    grad_eps: float = 1e-08
    approx_centrality_k: Optional[int] = None
    seed: int = 42
