from __future__ import annotations
import math
import networkx as nx
import numpy as np
import torch
import torch.nn.functional as F
from dataclasses import dataclass
from typing import List, Optional, Sequence, Tuple
from .config import CWSGConfig


@dataclass
class PatchGraph:
    positions: List[Tuple[int, int]]
    edge_index_unique: torch.Tensor
    lambda_sparse: torch.Tensor
    counts: torch.Tensor
    centrality: torch.Tensor
    w: torch.Tensor
    m: torch.Tensor
    patch_size: int
    stride: int
    image_hw: Tuple[int, int]

    @property
    def n_nodes(self) -> int:
        return len(self.positions)


def _active_patch_positions(mask: torch.Tensor, patch_size: int, stride: int, threshold: float) -> List[Tuple[int, int]]:
    h, w = mask.shape
    positions: List[Tuple[int, int]] = []
    for i in range(0, h - patch_size + 1, stride):
        for j in range(0, w - patch_size + 1, stride):
            patch = mask[i:i + patch_size, j:j + patch_size]
            if float(patch.float().mean().item()) >= threshold:
                positions.append((i, j))
    return positions


def _build_unique_edges(positions: Sequence[Tuple[int, int]], stride: int) -> torch.Tensor:
    coord_to_idx = {p: idx for idx, p in enumerate(positions)}
    edges: List[Tuple[int, int]] = []
    for idx, (i, j) in enumerate(positions):
        for ni, nj in ((i + stride, j), (i, j + stride)):
            other = coord_to_idx.get((ni, nj))
            if other is not None:
                edges.append((idx, other))
    if not edges:
        return torch.zeros((2, 0), dtype=torch.long)
    return torch.tensor(edges, dtype=torch.long).t().contiguous()


def _betweenness(edge_index_unique: torch.Tensor, n_nodes: int, approx_k: Optional[int], seed: int) -> torch.Tensor:
    graph = nx.Graph()
    graph.add_nodes_from(range(n_nodes))
    edges = edge_index_unique.cpu().numpy().T
    graph.add_edges_from(((int(a), int(b)) for a, b in edges))
    if approx_k is not None and approx_k > 0 and (approx_k < n_nodes):
        bc = nx.betweenness_centrality(graph, k=approx_k, seed=seed, normalized=False)
    else:
        bc = nx.betweenness_centrality(graph, normalized=False)
    values = np.asarray([bc.get(i, 0.0) for i in range(n_nodes)], dtype=np.float32)
    return torch.from_numpy(values)


def _fixed_lambda_sparse(edge_index_unique: torch.Tensor, n_nodes: int, device: torch.device) -> torch.Tensor:
    src = edge_index_unique[0]
    dst = edge_index_unique[1]
    row = torch.cat([torch.arange(n_nodes), src, dst]).to(device)
    col = torch.cat([torch.arange(n_nodes), dst, src]).to(device)
    val = torch.ones(row.numel(), device=device)
    a_tilde = torch.sparse_coo_tensor(torch.stack([row, col]), val, (n_nodes, n_nodes), device=device).coalesce()
    deg = torch.sparse.sum(a_tilde, dim=1).to_dense().clamp_min(1.0)
    inv_sqrt = deg.pow(-0.5)
    indices = a_tilde.indices()
    values = a_tilde.values() * inv_sqrt[indices[0]] * inv_sqrt[indices[1]]
    return torch.sparse_coo_tensor(indices, values, (n_nodes, n_nodes), device=device).coalesce()


def build_patch_graph(reference_channel: torch.Tensor, mask: torch.Tensor, cfg: CWSGConfig, device: torch.device) -> Tuple[PatchGraph, torch.Tensor]:
    h, w = reference_channel.shape[-2:]
    work_mask = mask.to(device).bool()
    positions = _active_patch_positions(work_mask, cfg.patch_size, cfg.stride, cfg.mask_patch_threshold)
    if not positions:
        print('[graph] No patch passed the mask gate; falling back to the full image.')
        work_mask = torch.ones((h, w), dtype=torch.bool, device=device)
        positions = _active_patch_positions(work_mask, cfg.patch_size, cfg.stride, cfg.mask_patch_threshold)
    edge_index_unique = _build_unique_edges(positions, cfg.stride).to(device)
    centrality = _betweenness(edge_index_unique, len(positions), cfg.approx_centrality_k, cfg.seed).to(device)
    grad_w = centrality / centrality.max().clamp_min(cfg.grad_eps)
    n_key = max(1, int(math.ceil(cfg.rho * len(positions))))
    key_nodes = torch.topk(grad_w, k=n_key).indices
    m = torch.full((len(positions),), cfg.background_weight, device=device)
    m[key_nodes] = 1.0
    lambda_sparse = _fixed_lambda_sparse(edge_index_unique, len(positions), device)
    ones = torch.ones((len(positions), cfg.patch_size * cfg.patch_size), device=device)
    counts = F.fold(ones.t().unsqueeze(0), output_size=(h, w), kernel_size=cfg.patch_size, stride=cfg.stride).squeeze(0)
    graph = PatchGraph(positions=list(positions), edge_index_unique=edge_index_unique, lambda_sparse=lambda_sparse, counts=counts, centrality=centrality, w=grad_w, m=m, patch_size=cfg.patch_size, stride=cfg.stride, image_hw=(h, w))
    return (graph, work_mask)


def image_to_nodes(channel: torch.Tensor, graph: PatchGraph) -> torch.Tensor:
    p = graph.patch_size
    return torch.stack([channel[:, i:i + p, j:j + p].reshape(-1) for i, j in graph.positions], dim=0)


def chebyshev_propagate(x: torch.Tensor, lambda_sparse: torch.Tensor, order: int=2) -> torch.Tensor:
    if order < 0:
        raise ValueError('filter order must be non-negative')
    out = x
    if order == 0:
        return out
    z_prev = x
    z_curr = torch.sparse.mm(lambda_sparse, x)
    out = out + 0.5 * z_curr
    for l in range(2, order + 1):
        z_next = 2.0 * torch.sparse.mm(lambda_sparse, z_curr) - z_prev
        out = out + 2.0 ** (-l) * z_next
        z_prev, z_curr = (z_curr, z_next)
    return out


def reconstruct_foreground(nodes: torch.Tensor, graph: PatchGraph, original_channel: torch.Tensor, mask: torch.Tensor, channel: str) -> torch.Tensor:
    ori_nodes = image_to_nodes(original_channel, graph)
    delta_nodes = nodes - ori_nodes
    if channel == 'H':
        delta_nodes = (delta_nodes + 0.5).remainder(1.0) - 0.5
    h, w = graph.image_hw
    folded_delta = F.fold(delta_nodes.t().unsqueeze(0), output_size=(h, w), kernel_size=graph.patch_size, stride=graph.stride).squeeze(0)
    coverage = graph.counts > 0
    avg_delta = folded_delta / graph.counts.clamp_min(1.0)
    if channel == 'H':
        recon = (original_channel + avg_delta).remainder(1.0)
    else:
        recon = (original_channel + avg_delta).clamp(0.0, 1.0)
    recon = torch.where(coverage, recon, original_channel)
    return torch.where(mask.unsqueeze(0), recon, original_channel)
