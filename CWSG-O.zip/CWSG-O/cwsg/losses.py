from __future__ import annotations
import math
import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision
from typing import List, Sequence, Tuple


def graph_tv_loss(nodes: torch.Tensor, edge_index_unique: torch.Tensor) -> torch.Tensor:
    if edge_index_unique.numel() == 0:
        return nodes.sum() * 0.0
    diffs = nodes[edge_index_unique[0]] - nodes[edge_index_unique[1]]
    return diffs.abs().sum(dim=1).mean()


def circular_hue_loss(h_adv: torch.Tensor, h_tar: torch.Tensor, mask_adv: torch.Tensor, mask_tar: torch.Tensor, window: int=9, stride: int=4) -> torch.Tensor:

    def window_features(h: torch.Tensor, mask: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        h_win = F.unfold(h.unsqueeze(0), kernel_size=window, stride=stride).squeeze(0).t()
        m_win = F.unfold(mask.float().unsqueeze(0).unsqueeze(0), kernel_size=window, stride=stride).squeeze(0).t()
        emb = torch.stack([torch.cos(2 * math.pi * h_win), torch.sin(2 * math.pi * h_win)], dim=-1)
        valid = m_win > 0.5
        counts = valid.sum(dim=1)
        weights = valid.float().unsqueeze(-1)
        mean = (emb * weights).sum(dim=1, keepdim=True) / counts.clamp_min(1).view(-1, 1, 1)
        centered = (emb - mean) * weights
        return (centered.reshape(centered.shape[0], -1), counts)
    f_adv, n_adv = window_features(h_adv, mask_adv)
    f_tar, n_tar = window_features(h_tar, mask_tar)
    valid = (n_adv > 0) & (n_tar > 0)
    if not bool(valid.any()):
        return h_adv.sum() * 0.0
    cosine = F.cosine_similarity(f_adv[valid], f_tar[valid], dim=1, eps=1e-08)
    return 1.0 - cosine.mean()


class VGGStyleExtractor(nn.Module):

    def __init__(self, device: torch.device):
        super().__init__()
        vgg = torchvision.models.vgg19(weights='IMAGENET1K_V1').features.to(device).eval()
        for p in vgg.parameters():
            p.requires_grad_(False)
        self.vgg = vgg
        self.style_layers = {1, 6, 11, 20, 29}

    def forward(self, x: torch.Tensor) -> List[torch.Tensor]:
        feats: List[torch.Tensor] = []
        for idx, layer in enumerate(self.vgg):
            x = layer(x)
            if idx in self.style_layers:
                feats.append(x)
        return feats


def gram_matrix(feat: torch.Tensor) -> torch.Tensor:
    b, c, h, w = feat.shape
    flat = feat.reshape(b * c, h * w)
    return flat @ flat.t() / float(b * c * h * w)


def masked_saturation_for_vgg(s: torch.Tensor, mask: torch.Tensor, img_size: int) -> torch.Tensor:
    x = (s * mask.float()).repeat(3, 1, 1).unsqueeze(0)
    if x.shape[-2:] != (img_size, img_size):
        x = F.interpolate(x, size=(img_size, img_size), mode='bilinear', align_corners=False)
    return x


def style_loss(feats_adv: Sequence[torch.Tensor], feats_tar: Sequence[torch.Tensor]) -> torch.Tensor:
    losses = []
    for fa, ft in zip(feats_adv, feats_tar):
        ga, gt = (gram_matrix(fa), gram_matrix(ft))
        losses.append(torch.mean((ga - gt) ** 2))
    return torch.stack(losses).sum()


def masked_frequency_loss(v_adv: torch.Tensor, v_tar: torch.Tensor, mask_adv: torch.Tensor, mask_tar: torch.Tensor) -> torch.Tensor:

    def centered(x: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
        m = mask.float()
        mean = (x * m).sum() / m.sum().clamp_min(1.0)
        return (x - mean) * m
    f_adv = torch.fft.fft2(centered(v_adv, mask_adv))
    f_tar = torch.fft.fft2(centered(v_tar, mask_tar))
    return (f_adv.abs() - f_tar.abs()).abs().mean()


@torch.no_grad()
def prepare_target_style_features(s_tar: torch.Tensor, mask_tar: torch.Tensor, extractor: VGGStyleExtractor, img_size: int) -> Sequence[torch.Tensor]:
    return extractor(masked_saturation_for_vgg(s_tar, mask_tar, img_size))
