from __future__ import annotations
import torch
from typing import Dict, List, Optional, Sequence, Tuple
from .color import hsv_to_rgb, project_nodes, rgb_to_hsv
from .config import CWSGConfig
from .graph import PatchGraph, build_patch_graph, chebyshev_propagate, image_to_nodes, reconstruct_foreground
from .losses import VGGStyleExtractor, circular_hue_loss, graph_tv_loss, masked_frequency_loss, masked_saturation_for_vgg, prepare_target_style_features, style_loss


def attack_one_channel(channel: str, x_ori_img: torch.Tensor, x_tar_img: torch.Tensor, mask_ori: torch.Tensor, mask_tar: torch.Tensor, graph: PatchGraph, cfg: CWSGConfig, style_extractor: Optional[VGGStyleExtractor]=None, target_style_feats: Optional[Sequence[torch.Tensor]]=None, img_size: int=224, verbose: bool=True) -> Tuple[torch.Tensor, torch.Tensor, List[Dict[str, float]]]:
    x_ori_nodes = image_to_nodes(x_ori_img, graph).detach()
    x = x_ori_nodes.clone().requires_grad_(True)
    momentum = torch.zeros_like(x)
    trace: List[Dict[str, float]] = []
    for t in range(cfg.steps):
        eta_t = cfg.eta * 2.0 ** (-2.0 * t / cfg.steps)
        tv_now = cfg.tv_lambda * min(1.0, 2.0 * t / cfg.steps)
        filtered = chebyshev_propagate(x, graph.lambda_sparse, cfg.filter_order)
        responses = filtered.abs().mean(dim=1)
        loss_spec = -(graph.m * responses).mean()
        loss_tv = graph_tv_loss(x, graph.edge_index_unique)
        recon = reconstruct_foreground(x, graph, x_ori_img, mask_ori, channel)
        if channel == 'H':
            loss_channel = circular_hue_loss(recon, x_tar_img, mask_ori, mask_tar)
            channel_weight = cfg.hue_weight
            channel_name = 'hue'
        elif channel == 'S':
            if style_extractor is None or target_style_feats is None:
                loss_channel = recon.sum() * 0.0
            else:
                adv_vgg = masked_saturation_for_vgg(recon, mask_ori, img_size)
                feats_adv = style_extractor(adv_vgg)
                loss_channel = style_loss(feats_adv, target_style_feats)
            channel_weight = cfg.style_weight
            channel_name = 'style'
        elif channel == 'V':
            loss_channel = masked_frequency_loss(recon, x_tar_img, mask_ori, mask_tar)
            channel_weight = cfg.freq_weight
            channel_name = 'freq'
        else:
            raise ValueError(f'Unknown channel: {channel}')
        loss = loss_spec + tv_now * loss_tv + channel_weight * loss_channel
        loss.backward()
        with torch.no_grad():
            grad = x.grad * graph.w.view(-1, 1)
            momentum.mul_(cfg.gamma).add_(grad / (grad.abs().mean() + cfg.grad_eps))
            x.copy_(project_nodes(x - eta_t * torch.sign(momentum), x_ori_nodes, cfg.eps, channel))
            x.grad.zero_()
        trace.append({'step': float(t + 1), 'loss': float(loss.detach().cpu()), 'spec': float(loss_spec.detach().cpu()), 'tv': float(loss_tv.detach().cpu()), channel_name: float(loss_channel.detach().cpu()), 'eta': float(eta_t), 'tv_lambda': float(tv_now)})
        if verbose and ((t + 1) % 5 == 0 or t == 0 or t + 1 == cfg.steps):
            print(f"[{channel} {t + 1:02d}/{cfg.steps}] loss={trace[-1]['loss']:.6f}, spec={trace[-1]['spec']:.6f}, tv={trace[-1]['tv']:.6f}, {channel_name}={trace[-1][channel_name]:.6f}")
    final_channel = reconstruct_foreground(x.detach(), graph, x_ori_img, mask_ori, channel)
    return (final_channel, x_ori_nodes, trace)


def cwsg_attack(img: torch.Tensor, target_img: torch.Tensor, mask_ori: torch.Tensor, mask_tar: torch.Tensor, cfg: CWSGConfig, device: torch.device, img_size: int=224, verbose: bool=True) -> Tuple[torch.Tensor, Dict[str, torch.Tensor], Dict[str, List[Dict[str, float]]], PatchGraph]:
    hsv_ori = rgb_to_hsv(img).to(device)
    hsv_tar = rgb_to_hsv(target_img).to(device)
    graph, mask_ori = build_patch_graph(hsv_ori[0:1], mask_ori, cfg, device)
    style_extractor: Optional[VGGStyleExtractor] = None
    target_style_feats: Optional[Sequence[torch.Tensor]] = None
    if cfg.style_weight != 0:
        style_extractor = VGGStyleExtractor(device)
        target_style_feats = prepare_target_style_features(hsv_tar[1:2], mask_tar, style_extractor, img_size)
    traces: Dict[str, List[Dict[str, float]]] = {}
    adv_channels: Dict[str, torch.Tensor] = {}
    for idx, channel in enumerate(('H', 'S', 'V')):
        if verbose:
            print(f'\n===== CWSG optimization on {channel} channel =====')
        adv_c, _, trace = attack_one_channel(channel=channel, x_ori_img=hsv_ori[idx:idx + 1], x_tar_img=hsv_tar[idx:idx + 1], mask_ori=mask_ori, mask_tar=mask_tar, graph=graph, cfg=cfg, style_extractor=style_extractor, target_style_feats=target_style_feats, img_size=img_size, verbose=verbose)
        adv_channels[channel] = adv_c
        traces[channel] = trace
    hsv_adv = torch.cat([adv_channels['H'], adv_channels['S'], adv_channels['V']], dim=0)
    rgb_adv = hsv_to_rgb(hsv_adv).clamp(0, 1)
    perturbations = {'H': (adv_channels['H'] - hsv_ori[0:1]).squeeze(0), 'S': (adv_channels['S'] - hsv_ori[1:2]).squeeze(0), 'V': (adv_channels['V'] - hsv_ori[2:3]).squeeze(0), 'RGB': rgb_adv - img}
    return (rgb_adv, perturbations, traces, graph)
