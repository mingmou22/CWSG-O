from __future__ import annotations
import torch
import torch.nn as nn
import torchvision
from typing import Dict


def _get_maskrcnn(device: torch.device) -> nn.Module:
    if device not in _MASKRCNN_CACHE:
        model = torchvision.models.detection.maskrcnn_resnet50_fpn(weights='DEFAULT')
        model.to(device).eval()
        for p in model.parameters():
            p.requires_grad_(False)
        _MASKRCNN_CACHE[device] = model
    return _MASKRCNN_CACHE[device]


@torch.no_grad()
def get_primary_foreground_mask(img: torch.Tensor, device: torch.device, detector_conf: float=0.5, mask_bin_threshold: float=0.5) -> torch.Tensor:
    h, w = img.shape[-2:]
    full_mask = torch.ones((h, w), dtype=torch.bool, device=device)
    try:
        model = _get_maskrcnn(device)
        out = model(img.unsqueeze(0).to(device))[0]
    except Exception as exc:
        print(f'[mask] Mask R-CNN unavailable ({exc}); using the full image.')
        return full_mask
    scores = out.get('scores', torch.empty(0, device=device))
    masks = out.get('masks', torch.empty(0, 1, h, w, device=device))
    valid = (scores >= detector_conf).nonzero().flatten()
    if valid.numel() == 0:
        print('[mask] No instance passed the confidence threshold; using the full image.')
        return full_mask
    best = valid[scores[valid].argmax().item()]
    mask = masks[best, 0] >= mask_bin_threshold
    if not bool(mask.any()):
        print('[mask] The selected instance produced an empty mask; using the full image.')
        return full_mask
    return mask


_MASKRCNN_CACHE: Dict[torch.device, nn.Module] = {}
