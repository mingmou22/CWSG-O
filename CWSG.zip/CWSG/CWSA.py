import torch
import torch.nn as nn
import torchvision
from torchvision import transforms
from torch_geometric.nn import GCNConv
import networkx as nx
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image
import argparse
import colorsys
import os
import random

plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

# ========== 基础函数/工具 ==========

def load_image(img_path, img_size=224, device='cpu'):
    img = Image.open(img_path).convert('RGB')
    tf = transforms.Compose([
        transforms.Resize([img_size, img_size]),
        transforms.ToTensor()
    ])
    tensor = tf(img).to(device)
    return tensor

def get_imagenet_labels(label_file="imagenet_classes.txt"):
    with open(label_file, 'r', encoding='utf-8') as f:
        labels = [line.strip() for line in f if line.strip()]
    return labels

def inv_transform(img):
    img = img.detach().cpu().numpy()
    img = np.transpose(img, (1, 2, 0))
    img = np.clip(img, 0, 1)
    img = (img * 255).astype(np.uint8)
    return img

def rgb_tensor_to_hsv(img):
    img_np = img.detach().cpu().permute(1,2,0).numpy()
    hsv = np.zeros_like(img_np)
    for i in range(img_np.shape[0]):
        for j in range(img_np.shape[1]):
            hsv[i,j] = colorsys.rgb_to_hsv(*img_np[i,j])
    hsv = torch.from_numpy(hsv).permute(2,0,1).type_as(img)
    return hsv.to(img.device)

def hsv_tensor_to_rgb(hsv_img):
    hsv_np = hsv_img.detach().cpu().permute(1,2,0).numpy()
    rgb = np.zeros_like(hsv_np)
    for i in range(hsv_np.shape[0]):
        for j in range(hsv_np.shape[1]):
            rgb[i,j] = colorsys.hsv_to_rgb(*hsv_np[i,j])
    rgb = torch.from_numpy(rgb).permute(2,0,1).type_as(hsv_img)
    return rgb.to(hsv_img.device)

def get_maskrcnn_mask(img, device, target_label=None, threshold=0.5):
    import torchvision
    model = torchvision.models.detection.maskrcnn_resnet50_fpn(weights="DEFAULT")
    model = model.to(device).eval()
    x = img.unsqueeze(0).to(device)
    with torch.no_grad():
        out = model(x)[0]
    if len(out['masks']) == 0:
        print('未检测到目标，mask全为0')
        return torch.zeros(img.shape[1:], dtype=torch.bool, device=device)
    scores = out['scores']
    masks = out['masks'][:,0] > threshold
    labels = out['labels']
    if target_label is not None:
        idxs = (labels == target_label).nonzero().flatten()
        if len(idxs) == 0:
            print('指定类别未检测到，mask全为0')
            return torch.zeros(img.shape[1:], dtype=torch.bool, device=device)
        best = idxs[scores[idxs].argmax().item()]
    else:
        best = scores.argmax().item()
    mask = masks[best]
    print(f'自动选择目标掩码, COCO类别id: {labels[best].item()}, score: {scores[best]:.3f}')
    return mask.to(device)

def image_to_overlapping_patches(img, patch_size=4, stride=2, mask=None):
    C, H, W = img.shape
    node_feats, idx_map = [], []
    group_ids = []
    gid = 0
    for i in range(0, H-patch_size+1, stride):
        for j in range(0, W-patch_size+1, stride):
            take = True
            if mask is not None:
                m_patch = mask[i:i+patch_size, j:j+patch_size]
                if m_patch.sum() < patch_size * patch_size * 0.4:
                    take = False
            if take:
                patch = img[:, i:i+patch_size, j:j+patch_size]
                node_feats.append(patch.reshape(-1))
                idx_map.append((i, j, gid, patch_size))
                group_ids.append(gid)
    if len(node_feats) == 0:
        raise RuntimeError("未找到patch，mask过小请检查！")
    node_feats = torch.stack(node_feats)
    edge_list = []
    coord2idx = { (i,j): idx for idx, (i,j,_,_) in enumerate(idx_map) }
    for idx, (i, j, _, _) in enumerate(idx_map):
        for dx, dy in [(-stride, 0), (0, -stride), (stride, 0), (0, stride)]:
            ni, nj = i+dx, j+dy
            if (ni, nj) in coord2idx:
                edge_list.append((idx, coord2idx[(ni, nj)]))
    edge_index = torch.tensor(edge_list, dtype=torch.long, device=img.device).T if edge_list else torch.zeros((2,0), dtype=torch.long, device=img.device)
    return node_feats, edge_index, idx_map, group_ids

class StructuralGNN(nn.Module):
    def __init__(self, in_dim, hidden=128):
        super().__init__()
        self.gcn1 = GCNConv(in_dim, hidden)
        self.gcn2 = GCNConv(hidden, 1)
    def forward(self, data):
        x, edge_index = data.x, data.edge_index
        h = torch.relu(self.gcn1(x, edge_index))
        score = self.gcn2(h, edge_index)
        return score.flatten()

class VGGStyleExtractor(nn.Module):
    def __init__(self, style_layers=None):
        super().__init__()
        vgg = torchvision.models.vgg16(weights="IMAGENET1K_V1").features.eval()
        for param in vgg.parameters():
            param.requires_grad = False
        self.vgg = vgg
        self.style_layers = style_layers or [1, 6, 11, 18, 25]
    def forward(self, x):
        feats = []
        for i, layer in enumerate(self.vgg):
            x = layer(x)
            if i in self.style_layers:
                feats.append(x)
        return feats

def gram_matrix(feat):
    a, b, c, d = feat.size()
    feat = feat.view(a * b, c * d)
    G = torch.mm(feat, feat.t())
    return G / (a * b * c * d)

def style_loss(feats_adv, feats_target):
    loss = 0
    for fa, ft in zip(feats_adv, feats_target):
        Ga, Gt = gram_matrix(fa), gram_matrix(ft)
        loss += torch.mean((Ga - Gt)**2)
    return loss

def preprocess_for_vgg(S, img_size):
    S_rgb = torch.cat([S, S, S], dim=0)
    S_rgb = transforms.Resize((img_size,img_size))(S_rgb)
    return S_rgb

def self_similarity_loss(src, tgt, window=9, stride=4):
    src = src.to(tgt.device)
    from torch.nn.functional import unfold
    src_p = unfold(src.unsqueeze(0), kernel_size=window, stride=stride)
    tgt_p = unfold(tgt.unsqueeze(0), kernel_size=window, stride=stride)
    src_p = src_p.squeeze(0).T
    tgt_p = tgt_p.squeeze(0).T
    src_p = src_p - src_p.mean(dim=1, keepdim=True)
    tgt_p = tgt_p - tgt_p.mean(dim=1, keepdim=True)
    src_norm = torch.norm(src_p, dim=1, keepdim=True) + 1e-8
    tgt_norm = torch.norm(tgt_p, dim=1, keepdim=True) + 1e-8
    src_p = src_p / src_norm
    tgt_p = tgt_p / tgt_norm
    sim_loss = 1 - (src_p * tgt_p).sum(dim=1).mean()
    return sim_loss

def freq_domain_loss(v_pred, v_target):
    v_pred = v_pred.to(v_target.device)
    v_pred_c = v_pred - v_pred.mean()
    v_target_c = v_target - v_target.mean()
    F_pred = torch.fft.fft2(v_pred_c)
    F_target = torch.fft.fft2(v_target_c)
    diff = torch.abs(torch.abs(F_pred) - torch.abs(F_target))
    return diff.mean()

def get_multi_models(device):
    models = []
    norm = transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
    model1 = torchvision.models.resnet50(weights='IMAGENET1K_V1').to(device).eval()
    models.append(('ResNet50', model1, norm))
    model2 = torchvision.models.mobilenet_v3_large(weights="IMAGENET1K_V1").to(device).eval()
    models.append(('MobileNetV3-Large', model2, norm))
    model3 = torchvision.models.vgg16(weights="IMAGENET1K_V1").to(device).eval()
    models.append(('VGG16', model3, norm))
    model4 = torchvision.models.efficientnet_b0(weights="IMAGENET1K_V1").to(device).eval()
    models.append(('EfficientNet-B0', model4, norm))
    return models

def predict(model, preprocess, img, device, classnames):
    x = preprocess(img).unsqueeze(0).to(device)
    with torch.no_grad():
        logits = model(x)
        pred = logits.argmax(dim=1).item()
    return pred, classnames[pred]

def predict_all_models(models, img, classnames):
    results = []
    for name, model, preprocess in models:
        pred_id, pred_name = predict(model, preprocess, img, next(model.parameters()).device, classnames)
        results.append((name, pred_id, pred_name))
    return results

def print_multi_model_preds(title, model_preds):
    print(f"{title}：")
    for model_name, pred_id, pred_name in model_preds:
        print(f"  {model_name}: {pred_id} - {pred_name}")

def show_images(img_list, titles=None, out_prefix=None):
    n = len(img_list)
    plt.figure(figsize=(5*n, 5))
    for i, img in enumerate(img_list):
        arr = inv_transform(img) if isinstance(img, torch.Tensor) else img
        plt.subplot(1, n, i+1)
        plt.imshow(arr)
        if titles:
            plt.title(titles[i], fontsize=10, wrap=True)
        plt.axis('off')
    plt.tight_layout()
    if out_prefix is not None:
        outname = f"{out_prefix}_compare.png"
        plt.savefig(outname)
        print(f"已保存可视化对比图: {outname}")
    plt.show()
    plt.close()

def show_mask(mask, save_path=None):
    plt.figure(figsize=(5,5))
    plt.imshow(mask.cpu().numpy(), cmap='gray')
    plt.title('分割掩码（白为目标区域）')
    plt.tight_layout()
    plt.axis('off')
    if save_path:
        plt.savefig(save_path)
        print(f"分割掩码已保存: {save_path}")
    plt.show()
    plt.close()

def plot_perturbation_map(pert_map, title, save_name):
    plt.figure(figsize=(5,5))
    p = plt.imshow(pert_map, cmap='jet')
    plt.colorbar(p, fraction=0.04)
    plt.title(title)
    plt.axis('off')
    plt.tight_layout()
    plt.savefig(save_name)
    print(f"{title} 已保存为 {save_name}")
    plt.show()
    plt.close()

# ========== 节点采样、重要性扰动相关部分 ==========
def select_nodes_by_centrality(centrality, ratio=0.3):
    n = centrality.shape[0]
    k = max(1, int(n * ratio))
    _, idx = torch.topk(centrality, k)
    return idx

def select_random_nodes(n, ratio=0.3, seed=None):
    k = max(1, int(n * ratio))
    if seed is not None:
        g = torch.Generator()
        g.manual_seed(seed)
        perm = torch.randperm(n, generator=g)
    else:
        perm = torch.randperm(n)
    return perm[:k]

def mask_grad_by_selected_nodes(grad, selected_nodes):
    keep_mask = torch.zeros(grad.shape[0], dtype=torch.bool, device=grad.device)
    keep_mask[selected_nodes] = True
    grad = grad.clone()
    grad[~keep_mask] = 0
    return grad

# ========== 攻击循环函数（带节点采样选项） ==========

def gnn_patch_attack_with_extra_loss(
    img, target_img, structural_gnn, device,
    patch_size=1, n_steps=40, adv_eps=8/255, lr=0.1, tv_lambda=1.0,
    extra_loss_func=None, extra_loss_weight=1.0, extra_loss_name="extra",
    verbose=True, mask=None, selected_nodes=None):
    img = img.to(device)
    target_img = target_img.to(device)
    node_feats, edge_index, idx_map, group_ids = image_to_overlapping_patches(
        img, patch_size=patch_size, stride=max(1, patch_size // 2), mask=mask)
    node_feats = node_feats.clone().detach().to(device)
    edge_index = edge_index.to(device)
    node_feats.requires_grad_(True)
    n_nodes = node_feats.shape[0]
    curr_in_dim = node_feats.shape[1]
    structural_gnn = StructuralGNN(in_dim=curr_in_dim, hidden=128).to(device)
    structural_gnn.eval()

    G = nx.DiGraph()
    G.add_nodes_from(range(n_nodes))
    edges = edge_index.cpu().numpy().T
    G.add_edges_from([tuple(e) for e in edges])
    centrality = torch.tensor(list(nx.betweenness_centrality(G).values()), device=device)
    imp_weight = centrality / (centrality.max() + 1e-6)
    topk = max(1, int(0.3 * n_nodes))
    main_nodes = centrality.topk(topk)[1]
    imp_mask = torch.full((n_nodes,), 0.2, device=device)
    imp_mask[main_nodes] = 1.0

    momentum = torch.zeros_like(node_feats)
    momentum_decay = 1.0
    loss_trace = []
    for step in range(n_steps):
        step_lr = lr * (0.5 ** (step / (n_steps // 2)))
        if step % 10 == 0:
            perm = torch.randperm(n_nodes, device=device)
            imp_mask[:] = 0.2
            imp_mask[perm[:topk]] = 1.0
        lambda_now = tv_lambda * min(1.0, step / (n_steps // 2))
        class GNNData:
            pass
        data = GNNData()
        data.x = node_feats
        data.edge_index = edge_index
        score = structural_gnn(data)
        loss_gnn = -(score * imp_mask).mean()
        if edge_index.shape[1] > 0:
            x_diffs = node_feats[edge_index[0]] - node_feats[edge_index[1]]
            loss_tv = x_diffs.abs().mean()
        else:
            loss_tv = 0.0
        img_patch = torch.zeros_like(img)
        counts = torch.zeros_like(img)
        for iidx, (i, j, gid, scale) in enumerate(idx_map):
            patch = node_feats[iidx].detach().reshape(img.shape[0], scale, scale)
            img_patch[:, i:i + scale, j:j + scale] += patch
            counts[:, i:i + scale, j:j + scale] += 1
        img_patch = img_patch / torch.clamp(counts, min=1)
        extra_loss = 0
        if extra_loss_func is not None:
            extra_loss = extra_loss_func(img_patch, target_img)
        loss = loss_gnn + lambda_now*loss_tv + extra_loss_weight*extra_loss

        loss.backward()
        grad = node_feats.grad
        grad = grad * imp_weight.view(-1, 1)
        if selected_nodes is not None:
            grad = mask_grad_by_selected_nodes(grad, selected_nodes)
        momentum = momentum_decay * momentum + grad / (grad.abs().mean() + 1e-8)
        node_feats.data = node_feats.data + step_lr * torch.sign(momentum)
        node_feats.data = torch.clamp(node_feats.data, 0, 1)
        node_feats.grad.zero_()
        loss_trace.append((loss.item(),
            loss_gnn.item() if hasattr(loss_gnn,'item') else loss_gnn,
            loss_tv.item() if hasattr(loss_tv,'item') else loss_tv,
            extra_loss.item() if hasattr(extra_loss, 'item') else extra_loss
        ))
        if verbose and (step % 10 == 0 or step == n_steps - 1):
            print(
                f"[{step + 1:02d}/{n_steps}] "
                f"loss={loss.item():.5f}, TV={loss_tv:.5f}, GNN={-loss_gnn:.5f}, "
                f"{extra_loss_name}={extra_loss.item() if isinstance(extra_loss, torch.Tensor) else extra_loss:.5f}")
    adv_img = torch.zeros_like(img)
    counts = torch.zeros_like(img)
    for iidx, (i, j, gid, scale) in enumerate(idx_map):
        patch = node_feats[iidx].detach().reshape(img.shape[0], scale, scale)
        adv_img[:, i:i + scale, j:j + scale] += patch
        counts[:, i:i + scale, j:j + scale] += 1
    counts = torch.clamp(counts, min=1)
    if mask is not None:
        mask3d = mask.float().unsqueeze(0)
        adv_img = img * (1 - mask3d) + (adv_img / counts) * mask3d
    else:
        adv_img = adv_img / counts
    adv_img = torch.clamp(adv_img, 0, 1)
    perturb = adv_img - img
    perturb = torch.clamp(perturb, -adv_eps, adv_eps)
    adv_img = torch.clamp(img + perturb, 0, 1)
    perturb_out = adv_img - img
    return adv_img, loss_trace, perturb_out

def gram_style_gnn_patch_attack(
    img, img_target, structural_gnn, device,
    patch_size=8, n_steps=40, adv_eps=12/255, lr=0.05,
    tv_lambda=0.2, verbose=True, mask=None, style_weight=1.0, img_size=224, selected_nodes=None
):
    extractor = VGGStyleExtractor().to(device).eval()
    img_rgb = preprocess_for_vgg(img, img_size).unsqueeze(0).to(device)
    target_rgb = preprocess_for_vgg(img_target, img_size).unsqueeze(0).to(device)
    feats_target = extractor(target_rgb)
    img = img.to(device)
    img_target = img_target.to(device)
    node_feats, edge_index, idx_map, group_ids = image_to_overlapping_patches(
        img, patch_size=patch_size, stride=max(1, patch_size // 2), mask=mask)
    node_feats = node_feats.clone().detach().to(device)
    edge_index = edge_index.to(device)
    node_feats.requires_grad_(True)
    n_nodes = node_feats.shape[0]
    curr_in_dim = node_feats.shape[1]
    structural_gnn = StructuralGNN(in_dim=curr_in_dim, hidden=128).to(device)
    structural_gnn.eval()
    G = nx.DiGraph()
    G.add_nodes_from(range(n_nodes))
    edges = edge_index.cpu().numpy().T
    G.add_edges_from([tuple(e) for e in edges])
    centrality = torch.tensor(list(nx.betweenness_centrality(G).values()), device=device)
    imp_weight = centrality / (centrality.max() + 1e-6)
    topk = max(1, int(0.3 * n_nodes))
    main_nodes = centrality.topk(topk)[1]
    imp_mask = torch.full((n_nodes,), 0.2, device=device)
    imp_mask[main_nodes] = 1.0

    momentum = torch.zeros_like(node_feats)
    momentum_decay = 1.0
    loss_trace = []
    for step in range(n_steps):
        step_lr = lr * (0.5 ** (step / (n_steps // 2)))
        if step % 10 == 0:
            perm = torch.randperm(n_nodes, device=device)
            imp_mask[:] = 0.2
            imp_mask[perm[:topk]] = 1.0
        lambda_now = tv_lambda * min(1.0, step / (n_steps // 2))
        class GNNData:
            pass
        data = GNNData()
        data.x = node_feats
        data.edge_index = edge_index
        score = structural_gnn(data)
        loss_gnn = -(score * imp_mask).mean()
        if edge_index.shape[1] > 0:
            x_diffs = node_feats[edge_index[0]] - node_feats[edge_index[1]]
            loss_tv = x_diffs.abs().mean()
        else:
            loss_tv = 0.0
        s_patch_img = torch.zeros_like(img)
        counts = torch.zeros_like(img)
        for iidx, (i, j, gid, scale) in enumerate(idx_map):
            patch = node_feats[iidx].detach().reshape(img.shape[0], scale, scale)
            s_patch_img[:, i:i + scale, j:j + scale] += patch
            counts[:, i:i + scale, j:j + scale] += 1
        s_patch_img = s_patch_img / torch.clamp(counts, min=1)
        s_rgb = preprocess_for_vgg(s_patch_img, img_size).unsqueeze(0).to(device)
        feats_adv = extractor(s_rgb)
        loss_style = style_loss(feats_adv, feats_target)
        loss = loss_gnn + lambda_now*loss_tv + style_weight*loss_style
        loss.backward()
        grad = node_feats.grad
        grad = grad * imp_weight.view(-1, 1)
        if selected_nodes is not None:
            grad = mask_grad_by_selected_nodes(grad, selected_nodes)
        momentum = momentum_decay * momentum + grad / (grad.abs().mean() + 1e-8)
        node_feats.data = node_feats.data + step_lr * torch.sign(momentum)
        node_feats.data = torch.clamp(node_feats.data, 0, 1)
        node_feats.grad.zero_()
        loss_trace.append((loss.item(), loss_gnn.item(), loss_tv.item(), loss_style.item()))
        if verbose and (step % 10 == 0 or step == n_steps - 1):
            print(
                f"[{step + 1:02d}/{n_steps}] loss={loss.item():.5f}, TV={loss_tv:.5f}, GNN={-loss_gnn:.5f}, style={loss_style:.5f}")
    adv_img = torch.zeros_like(img)
    counts = torch.zeros_like(img)
    for iidx, (i, j, gid, scale) in enumerate(idx_map):
        patch = node_feats[iidx].detach().reshape(img.shape[0], scale, scale)
        adv_img[:, i:i + scale, j:j + scale] += patch
        counts[:, i:i + scale, j:j + scale] += 1
    counts = torch.clamp(counts, min=1)
    if mask is not None:
        mask3d = mask.float().unsqueeze(0)
        adv_img = img * (1 - mask3d) + (adv_img / counts) * mask3d
    else:
        adv_img = adv_img / counts
    adv_img = torch.clamp(adv_img, 0, 1)
    perturb_out = adv_img - img
    perturb = torch.clamp(perturb_out, -adv_eps, adv_eps)
    adv_img = torch.clamp(img + perturb, 0, 1)
    return adv_img, loss_trace, perturb_out

def hsv_channel_gnn_patch_attack(
    img, target_img, device,
    patch_size=8, n_steps=40, adv_eps=12/255, lr=0.05,
    tv_lambda=0.2, style_weight=1.0, fractal_weight=1.0, freq_weight=1.0,
    verbose=True, mask=None, img_size=224,
    node_select_mode="all", node_select_ratio=0.3, random_seed=42):

    hsv_img = rgb_tensor_to_hsv(img)
    hsv_target = rgb_tensor_to_hsv(target_img)
    H = hsv_img[0:1,:,:].to(device)
    S = hsv_img[1:2,:,:].to(device)
    V = hsv_img[2:3,:,:].to(device)
    H_target = hsv_target[0:1,:,:].to(device)
    S_target = hsv_target[1:2,:,:].to(device)
    V_target = hsv_target[2:3,:,:].to(device)
    in_dim = 1 * patch_size * patch_size

    def get_selected_nodes_helper(channel_tensor, mask):
        node_feats, edge_index, idx_map, group_ids = image_to_overlapping_patches(
            channel_tensor, patch_size=patch_size, stride=max(1, patch_size // 2), mask=mask)
        n_nodes = node_feats.shape[0]
        G = nx.DiGraph()
        G.add_nodes_from(range(n_nodes))
        edges = edge_index.cpu().numpy().T
        G.add_edges_from([tuple(e) for e in edges])
        centrality = torch.tensor(list(nx.betweenness_centrality(G).values()), device=channel_tensor.device)
        if node_select_mode == "all":
            return None
        elif node_select_mode == "important":
            return select_nodes_by_centrality(centrality, node_select_ratio)
        elif node_select_mode == "random":
            return select_random_nodes(n_nodes, node_select_ratio, seed=random_seed)
        else:
            raise ValueError("node_select_mode should be all, important, or random")

    print(">>>> 攻击 H 通道（结构+分形loss）")
    gnn_H = StructuralGNN(in_dim=in_dim, hidden=128).to(device)
    h_selected_nodes = get_selected_nodes_helper(H, mask)
    h_adv, h_loss_trace, h_perturb = gnn_patch_attack_with_extra_loss(
        H, H_target, gnn_H, device, patch_size, n_steps, adv_eps, lr, tv_lambda,
        extra_loss_func=self_similarity_loss, extra_loss_weight=fractal_weight,
        extra_loss_name="fractal", verbose=verbose, mask=mask, selected_nodes=h_selected_nodes)

    print(">>>> 攻击 S 通道（结构+风格loss）")
    gnn_S = StructuralGNN(in_dim=in_dim, hidden=128).to(device)
    s_selected_nodes = get_selected_nodes_helper(S, mask)
    s_adv, s_loss_trace, s_perturb = gram_style_gnn_patch_attack(
        S, S_target, gnn_S, device,
        patch_size=patch_size, n_steps=n_steps, adv_eps=adv_eps, lr=lr,
        tv_lambda=tv_lambda, verbose=verbose, mask=mask, style_weight=style_weight, img_size=img_size,
        selected_nodes=s_selected_nodes
    )

    print(">>>> 攻击 V 通道（结构+频域loss）")
    gnn_V = StructuralGNN(in_dim=in_dim, hidden=128).to(device)
    v_selected_nodes = get_selected_nodes_helper(V, mask)
    v_adv, v_loss_trace, v_perturb = gnn_patch_attack_with_extra_loss(
        V, V_target, gnn_V, device, patch_size, n_steps, adv_eps, lr, tv_lambda,
        extra_loss_func=freq_domain_loss, extra_loss_weight=freq_weight,
        extra_loss_name="freq", verbose=verbose, mask=mask, selected_nodes=v_selected_nodes)

    hsv_adv_img = torch.cat([h_adv, s_adv, v_adv], dim=0)
    rgb_adv_img = hsv_tensor_to_rgb(hsv_adv_img)
    rgb_adv_img = torch.clamp(rgb_adv_img, 0, 1)
    h_pert = h_perturb.squeeze(0).detach().cpu().numpy()
    s_pert = s_perturb.squeeze(0).detach().cpu().numpy()
    v_pert = v_perturb.squeeze(0).detach().cpu().numpy()
    return rgb_adv_img, (h_pert, s_pert, v_pert)

# ========== 主程序入口 ==========

def main(args):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"运行设备: {device}")
    label_file = args.label_file
    classnames = get_imagenet_labels(label_file)
    img = load_image(args.img, img_size=args.img_size, device=device)
    target_img = load_image(args.target_img, img_size=args.img_size, device=device)
    print("图片加载完成:", img.shape, target_img.shape)
    models = get_multi_models(device)
    orig_preds = predict_all_models(models, img, classnames)
    print_multi_model_preds("原始模型预测", orig_preds)
    mask = get_maskrcnn_mask(img, device, target_label=args.target_label).to(device)
    show_mask(mask, save_path="visual_mask.png")
    adv_img, (h_pert, s_pert, v_pert) = hsv_channel_gnn_patch_attack(
        img, target_img, device,
        patch_size=args.patch_size, n_steps=args.n_steps, adv_eps=args.eps, lr=args.lr,
        tv_lambda=args.tv_lambda, verbose=True, mask=mask, style_weight=args.style_weight,
        fractal_weight=args.fractal_weight, freq_weight=args.freq_weight, img_size=args.img_size,
        node_select_mode=args.node_select_mode, node_select_ratio=args.node_select_ratio, random_seed=args.seed
    )
    adv_preds = predict_all_models(models, adv_img, classnames)
    print_multi_model_preds("对抗扰动后模型预测", adv_preds)
    viz_imgs = [img.cpu(), target_img.cpu(), adv_img.cpu()]
    viz_titles = [
        "原图",
        "目标图",
        "扰动对抗图像"
    ]
    show_images(viz_imgs, viz_titles, out_prefix="pert_visual")
    for pert_map, pertname, visname in zip(
        [h_pert, s_pert, v_pert],
        ['H通道扰动', 'S通道扰动', 'V通道扰动'],
        ['perturb_H.png','perturb_S.png','perturb_V.png']
        ):
        plot_perturbation_map(pert_map, pertname, visname)
    out_img = inv_transform(adv_img.cpu())
    Image.fromarray(out_img).save("gnn_hsv_adv_full.png")
    print("已保存扰动图像为 gnn_hsv_adv_full.png")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--img', type=str, default="3.jpg")
    parser.add_argument('--target_img', type=str, default="b1.png", help="目标图片（风格/结构引导）")
    parser.add_argument('--img_size', type=int, default=224)
    parser.add_argument('--patch_size', type=int, default=8)
    parser.add_argument('--n_steps', type=int, default=20)
    parser.add_argument('--eps', type=float, default=8/255)
    parser.add_argument('--lr', type=float, default=0.1)
    parser.add_argument('--tv_lambda', type=float, default=0.2)
    parser.add_argument('--style_weight', type=float, default=1.0, help="S通道风格loss权重")
    parser.add_argument('--fractal_weight', type=float, default=1.0, help="H通道分形loss权重")
    parser.add_argument('--freq_weight', type=float, default=1.0, help="V通道频域loss权重")
    parser.add_argument('--label_file', type=str, default="imagenet_classes.txt")
    parser.add_argument('--target_label', type=int, default=None, help="（可选）指定COCO分割类别id")
    parser.add_argument('--node_select_mode', type=str, default="all", choices=["all", "important", "random"],
                        help="扰动节点选择方式：all全部、important关键节点、random随机节点")
    parser.add_argument('--node_select_ratio', type=float, default=0.3, help="节点采样占比（主节点比例）")
    parser.add_argument('--seed', type=int, default=42, help="随机扰动实验随机种子")
    args = parser.parse_args()
    main(args)