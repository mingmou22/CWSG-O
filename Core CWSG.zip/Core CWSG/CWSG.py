CWSG: Channel-wise Structure-Guided black-box adversarial attack.

This implementation follows the algorithm section of the manuscript:
1. Symmetric HSV decomposition and Mask R-CNN foreground masks.
2. Mask-gated patch graph with betweenness-centrality key-region selection.
3. Fixed, parameter-free Chebyshev spectral propagation.
4. Channel-specific hue, style, and frequency alignment losses.
5. Centrality-weighted momentum sign updates with per-channel budget projection.


from __future__ import annotations

import argparse
import json
import math
import os
import random
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import networkx as nx
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision
from PIL import Image
from torchvision import transforms




def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def load_image(path: str | Path, img_size: int, device: torch.device) -> torch.Tensor:
    img = Image.open(path).convert("RGB")
    tf = transforms.Compose(
        [transforms.Resize((img_size, img_size)), transforms.ToTensor()]
    )
    return tf(img).to(device)


def tensor_to_pil(img: torch.Tensor) -> Image.Image:
    arr = img.detach().cpu().clamp(0, 1).permute(1, 2, 0).numpy()
    return Image.fromarray((arr * 255).round().astype(np.uint8))


def save_tensor_image(img: torch.Tensor, path: str | Path) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tensor_to_pil(img).save(path)


def save_comparison(images: Sequence[torch.Tensor], titles: Sequence[str], path: str | Path) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    n = len(images)
    fig, axes = plt.subplots(1, n, figsize=(4.2 * n, 4.2))
    if n == 1:
        axes = [axes]
    for ax, img, title in zip(axes, images, titles):
        ax.imshow(tensor_to_pil(img))
        ax.set_title(title)
        ax.axis("off")
    fig.tight_layout()
    fig.savefig(path, dpi=180)
    plt.close(fig)


def save_heatmap(values: np.ndarray, title: str, path: str | Path) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fig, ax = plt.subplots(figsize=(4.5, 4.0))
    im = ax.imshow(values, cmap="jet")
    ax.set_title(title)
    ax.axis("off")
    fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    fig.tight_layout()
    fig.savefig(path, dpi=180)
    plt.close(fig)



def rgb_to_hsv(img: torch.Tensor, eps: float = 1e-8) -> torch.Tensor:
    """Convert an RGB tensor of shape [3, H, W] to HSV in [0, 1]."""
    r, g, b = img[0], img[1], img[2]
    maxc = torch.maximum(torch.maximum(r, g), b)
    minc = torch.minimum(torch.minimum(r, g), b)
    chroma = maxc - minc
    safe_chroma = chroma.clamp_min(eps)

    rc = (maxc - r) / safe_chroma
    gc = (maxc - g) / safe_chroma
    bc = (maxc - b) / safe_chroma

    h = torch.where(
        maxc == r,
        bc - gc,
        torch.where(maxc == g, 2.0 + rc - bc, 4.0 + gc - rc),
    )
    h = (h / 6.0).remainder(1.0)
    h = torch.where(chroma <= eps, torch.zeros_like(h), h)
    s = torch.where(maxc <= eps, torch.zeros_like(maxc), chroma / maxc.clamp_min(eps))
    v = maxc
    return torch.stack([h, s, v], dim=0)


def _hsv_channel_select(i: torch.Tensor, values: Sequence[torch.Tensor]) -> torch.Tensor:
    out = values[-1]
    for k in range(len(values) - 2, -1, -1):
        out = torch.where(i == k, values[k], out)
    return out


def hsv_to_rgb(hsv: torch.Tensor) -> torch.Tensor:
    """Convert an HSV tensor of shape [3, H, W] to RGB in [0, 1]."""
    h, s, v = hsv[0].remainder(1.0), hsv[1].clamp(0, 1), hsv[2].clamp(0, 1)
    h6 = h * 6.0
    i_float = torch.floor(h6)
    f = h6 - i_float
    i = i_float.to(torch.int64).remainder(6)

    p = v * (1.0 - s)
    q = v * (1.0 - f * s)
    t = v * (1.0 - (1.0 - f) * s)

    r = _hsv_channel_select(i, [v, q, p, p, t, v])
    g = _hsv_channel_select(i, [t, v, v, q, p, p])
    b = _hsv_channel_select(i, [p, p, t, v, v, q])
    return torch.stack([r, g, b], dim=0).clamp(0, 1)


_MASKRCNN_CACHE: Dict[torch.device, nn.Module] = {}


def _get_maskrcnn(device: torch.device) -> nn.Module:
    if device not in _MASKRCNN_CACHE:
        model = torchvision.models.detection.maskrcnn_resnet50_fpn(weights="DEFAULT")
        model.to(device).eval()
        for p in model.parameters():
            p.requires_grad_(False)
        _MASKRCNN_CACHE[device] = model
    return _MASKRCNN_CACHE[device]


@torch.no_grad()
def get_primary_foreground_mask(
    img: torch.Tensor,
    device: torch.device,
    detector_conf: float = 0.5,
    mask_bin_threshold: float = 0.5,
) -> torch.Tensor:
    """Return the primary-instance boolean mask; fall back to the full image."""
    h, w = img.shape[-2:]
    full_mask = torch.ones((h, w), dtype=torch.bool, device=device)
    try:
        model = _get_maskrcnn(device)
        out = model(img.unsqueeze(0).to(device))[0]
    except Exception as exc:  # Download/runtime failures should not make a sample unattacked.
        print(f"[mask] Mask R-CNN unavailable ({exc}); using the full image.")
        return full_mask

    scores = out.get("scores", torch.empty(0, device=device))
    masks = out.get("masks", torch.empty(0, 1, h, w, device=device))
    valid = (scores >= detector_conf).nonzero().flatten()
    if valid.numel() == 0:
        print("[mask] No instance passed the confidence threshold; using the full image.")
        return full_mask

    best = valid[scores[valid].argmax().item()]
    mask = masks[best, 0] >= mask_bin_threshold
    if not bool(mask.any()):
        print("[mask] The selected instance produced an empty mask; using the full image.")
        return full_mask
    return mask


@dataclass
class CWSGConfig:
    patch_size: int = 8
    stride: int = 4
    steps: int = 20
    eps: float = 8.0 / 255.0
    eta: float = 0.1
    gamma: float = 1.0
    tv_lambda: float = 0.2
    filter_order: int = 2
    rho: float = 0.3
    background_weight: float = 0.2
    mask_patch_threshold: float = 0.4
    hue_weight: float = 1.0
    style_weight: float = 1.0
    freq_weight: float = 1.0
    grad_eps: float = 1e-8
    approx_centrality_k: Optional[int] = None
    seed: int = 42


@dataclass
class PatchGraph:
    positions: List[Tuple[int, int]]
    edge_index_unique: torch.Tensor  # [2, E], each undirected edge once
    lambda_sparse: torch.Tensor  # rescaled Laplacian Lambda = L_tilde - I
    counts: torch.Tensor  # [1, H, W]
    centrality: torch.Tensor  # [N]
    w: torch.Tensor  # continuous gradient weight
    m: torch.Tensor  # binary emphasis weight, 1.0 in K and background_weight elsewhere
    patch_size: int
    stride: int
    image_hw: Tuple[int, int]

    @property
    def n_nodes(self) -> int:
        return len(self.positions)


def _active_patch_positions(
    mask: torch.Tensor,
    patch_size: int,
    stride: int,
    threshold: float,
) -> List[Tuple[int, int]]:
    h, w = mask.shape
    positions: List[Tuple[int, int]] = []
    for i in range(0, h - patch_size + 1, stride):
        for j in range(0, w - patch_size + 1, stride):
            patch = mask[i : i + patch_size, j : j + patch_size]
            if float(patch.float().mean().item()) >= threshold:
                positions.append((i, j))
    return positions


def _build_unique_edges(
    positions: Sequence[Tuple[int, int]], stride: int
) -> torch.Tensor:
    coord_to_idx = {p: idx for idx, p in enumerate(positions)}
    edges: List[Tuple[int, int]] = []
    for idx, (i, j) in enumerate(positions):
        for ni, nj in ((i + stride, j), (i, j + stride)):
            other = coord_to_idx.get((ni, nj))
            if other is not None:
                edges.append((idx, other))
    if not edges:
        return torch.zeros((2, 0), dtype=torch.long)
    return torch.tensor(edges, dtype=torch.long).t().contiguous()


def _betweenness(
    edge_index_unique: torch.Tensor,
    n_nodes: int,
    approx_k: Optional[int],
    seed: int,
) -> torch.Tensor:
    graph = nx.Graph()
    graph.add_nodes_from(range(n_nodes))
    edges = edge_index_unique.cpu().numpy().T
    graph.add_edges_from((int(a), int(b)) for a, b in edges)
    if approx_k is not None and approx_k > 0 and approx_k < n_nodes:
        bc = nx.betweenness_centrality(graph, k=approx_k, seed=seed, normalized=False)
    else:
        bc = nx.betweenness_centrality(graph, normalized=False)
    values = np.asarray([bc.get(i, 0.0) for i in range(n_nodes)], dtype=np.float32)
    return torch.from_numpy(values)


def _fixed_lambda_sparse(
    edge_index_unique: torch.Tensor,
    n_nodes: int,
    device: torch.device,
) -> torch.Tensor:
    """Build Lambda = L_tilde - I with A_tilde = A + I.

    Since L_tilde = I - D_tilde^{-1/2} A_tilde D_tilde^{-1/2},
    Lambda equals minus the symmetrically normalized adjacency.
    """
    src = edge_index_unique[0]
    dst = edge_index_unique[1]
    row = torch.cat([torch.arange(n_nodes), src, dst]).to(device)
    col = torch.cat([torch.arange(n_nodes), dst, src]).to(device)
    val = torch.ones(row.numel(), device=device)
    a_tilde = torch.sparse_coo_tensor(
        torch.stack([row, col]), val, (n_nodes, n_nodes), device=device
    ).coalesce()
    deg = torch.sparse.sum(a_tilde, dim=1).to_dense().clamp_min(1.0)
    inv_sqrt = deg.pow(-0.5)
    indices = a_tilde.indices()
    values = a_tilde.values() * inv_sqrt[indices[0]] * inv_sqrt[indices[1]]
    return torch.sparse_coo_tensor(indices, -values, (n_nodes, n_nodes), device=device).coalesce()


def build_patch_graph(
    reference_channel: torch.Tensor,
    mask: torch.Tensor,
    cfg: CWSGConfig,
    device: torch.device,
) -> Tuple[PatchGraph, torch.Tensor]:
    """Build the shared mask-gated graph. The returned mask may be full-image fallback."""
    h, w = reference_channel.shape[-2:]
    work_mask = mask.to(device).bool()
    positions = _active_patch_positions(
        work_mask, cfg.patch_size, cfg.stride, cfg.mask_patch_threshold
    )
    if not positions:
        print("[graph] No patch passed the mask gate; falling back to the full image.")
        work_mask = torch.ones((h, w), dtype=torch.bool, device=device)
        positions = _active_patch_positions(
            work_mask, cfg.patch_size, cfg.stride, cfg.mask_patch_threshold
        )

    edge_index_unique = _build_unique_edges(positions, cfg.stride).to(device)
    centrality = _betweenness(
        edge_index_unique, len(positions), cfg.approx_centrality_k, cfg.seed
    ).to(device)
    grad_w = centrality / centrality.max().clamp_min(cfg.grad_eps)

    n_key = max(1, int(math.ceil(cfg.rho * len(positions))))
    key_nodes = torch.topk(grad_w, k=n_key).indices
    m = torch.full((len(positions),), cfg.background_weight, device=device)
    m[key_nodes] = 1.0

    lambda_sparse = _fixed_lambda_sparse(edge_index_unique, len(positions), device)
    ones = torch.ones((len(positions), cfg.patch_size * cfg.patch_size), device=device)
    counts = F.fold(
        ones.t().unsqueeze(0),
        output_size=(h, w),
        kernel_size=cfg.patch_size,
        stride=cfg.stride,
    ).squeeze(0)

    graph = PatchGraph(
        positions=list(positions),
        edge_index_unique=edge_index_unique,
        lambda_sparse=lambda_sparse,
        counts=counts,
        centrality=centrality,
        w=grad_w,
        m=m,
        patch_size=cfg.patch_size,
        stride=cfg.stride,
        image_hw=(h, w),
    )
    return graph, work_mask


def image_to_nodes(channel: torch.Tensor, graph: PatchGraph) -> torch.Tensor:
    p = graph.patch_size
    return torch.stack(
        [channel[:, i : i + p, j : j + p].reshape(-1) for i, j in graph.positions], dim=0
    )


def nodes_to_image(
    nodes: torch.Tensor,
    graph: PatchGraph,
    background: torch.Tensor,
) -> torch.Tensor:
    h, w = graph.image_hw
    folded = F.fold(
        nodes.t().unsqueeze(0),
        output_size=(h, w),
        kernel_size=graph.patch_size,
        stride=graph.stride,
    ).squeeze(0)
    coverage = graph.counts > 0
    averaged = folded / graph.counts.clamp_min(1.0)
    return torch.where(coverage, averaged, background)


def chebyshev_propagate(
    x: torch.Tensor,
    lambda_sparse: torch.Tensor,
    order: int = 2,
) -> torch.Tensor:
    """Apply sum_{l=0}^K 2^{-l} T_l(Lambda) x."""
    if order < 0:
        raise ValueError("filter order must be non-negative")
    out = x
    if order == 0:
        return out
    z_prev = x
    z_curr = torch.sparse.mm(lambda_sparse, x)
    out = out + 0.5 * z_curr
    for l in range(2, order + 1):
        z_next = 2.0 * torch.sparse.mm(lambda_sparse, z_curr) - z_prev
        out = out + (2.0 ** (-l)) * z_next
        z_prev, z_curr = z_curr, z_next
    return out


def graph_tv_loss(nodes: torch.Tensor, edge_index_unique: torch.Tensor) -> torch.Tensor:
    if edge_index_unique.numel() == 0:
        return nodes.sum() * 0.0
    diffs = nodes[edge_index_unique[0]] - nodes[edge_index_unique[1]]
    return diffs.abs().mean()


def circular_hue_loss(
    h_adv: torch.Tensor,
    h_tar: torch.Tensor,
    mask_adv: torch.Tensor,
    mask_tar: torch.Tensor,
    window: int = 9,
    stride: int = 4,
) -> torch.Tensor:
    """Cosine distance between mean-centered circular hue embeddings in windows."""

    def window_features(h: torch.Tensor, mask: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        h_win = F.unfold(h.unsqueeze(0), kernel_size=window, stride=stride).squeeze(0).t()
        m_win = F.unfold(
            mask.float().unsqueeze(0).unsqueeze(0), kernel_size=window, stride=stride
        ).squeeze(0).t()
        emb = torch.stack([torch.cos(2 * math.pi * h_win), torch.sin(2 * math.pi * h_win)], dim=-1)
        valid = m_win > 0.5
        counts = valid.sum(dim=1).clamp_min(1)
        weights = valid.float().unsqueeze(-1)
        mean = (emb * weights).sum(dim=1, keepdim=True) / counts.view(-1, 1, 1)
        centered = (emb - mean) * weights
        return centered.reshape(centered.shape[0], -1), counts

    f_adv, n_adv = window_features(h_adv, mask_adv)
    f_tar, n_tar = window_features(h_tar, mask_tar)
    valid = (n_adv > 0) & (n_tar > 0)
    if not bool(valid.any()):
        return h_adv.sum() * 0.0
    cosine = F.cosine_similarity(f_adv[valid], f_tar[valid], dim=1, eps=1e-8)
    return 1.0 - cosine.mean()


class VGGStyleExtractor(nn.Module):
    """Frozen VGG-16 feature extractor for relu1_1, ..., relu5_1."""

    def __init__(self, device: torch.device):
        super().__init__()
        vgg = torchvision.models.vgg16(weights="IMAGENET1K_V1").features.to(device).eval()
        for p in vgg.parameters():
            p.requires_grad_(False)
        self.vgg = vgg
        self.style_layers = {1, 6, 11, 18, 25}

    def forward(self, x: torch.Tensor) -> List[torch.Tensor]:
        feats: List[torch.Tensor] = []
        for idx, layer in enumerate(self.vgg):
            x = layer(x)
            if idx in self.style_layers:
                feats.append(x)
        return feats


def gram_matrix(feat: torch.Tensor) -> torch.Tensor:
    b, c, h, w = feat.shape
    flat = feat.reshape(b * c, h * w)
    return flat @ flat.t() / float(b * c * h * w)


def masked_saturation_for_vgg(
    s: torch.Tensor,
    mask: torch.Tensor,
    img_size: int,
) -> torch.Tensor:
    x = (s * mask.float()).repeat(3, 1, 1).unsqueeze(0)
    if x.shape[-2:] != (img_size, img_size):
        x = F.interpolate(x, size=(img_size, img_size), mode="bilinear", align_corners=False)
    return x


def style_loss(feats_adv: Sequence[torch.Tensor], feats_tar: Sequence[torch.Tensor]) -> torch.Tensor:
    losses = []
    for fa, ft in zip(feats_adv, feats_tar):
        ga, gt = gram_matrix(fa), gram_matrix(ft)
        losses.append(torch.mean((ga - gt) ** 2))
    return torch.stack(losses).sum()


def masked_frequency_loss(
    v_adv: torch.Tensor,
    v_tar: torch.Tensor,
    mask_adv: torch.Tensor,
    mask_tar: torch.Tensor,
) -> torch.Tensor:
    def centered(x: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
        m = mask.float()
        mean = (x * m).sum() / m.sum().clamp_min(1.0)
        return (x - mean) * m

    f_adv = torch.fft.fft2(centered(v_adv, mask_adv))
    f_tar = torch.fft.fft2(centered(v_tar, mask_tar))
    return (f_adv.abs() - f_tar.abs()).abs().mean()


def project_nodes(
    x: torch.Tensor,
    x_ori: torch.Tensor,
    eps: float,
    channel: str,
) -> torch.Tensor:
    delta = x - x_ori
    if channel == "H":
        delta = (delta + 0.5).remainder(1.0) - 0.5
        delta = delta.clamp(-eps, eps)
        return (x_ori + delta).remainder(1.0)
    delta = delta.clamp(-eps, eps)
    return (x_ori + delta).clamp(0.0, 1.0)


def reconstruct_foreground(
    nodes: torch.Tensor,
    graph: PatchGraph,
    original_channel: torch.Tensor,
    mask: torch.Tensor,
    channel: str,
) -> torch.Tensor:
    """Reconstruct from overlapping node deltas, using circular averaging for hue.

    Folding wrapped hue values directly can average 0.99 and 0.01 to an invalid
    intermediate hue near 0.5. Averaging per-patch deltas preserves the intended
    circular perturbation and keeps the reconstructed pixel inside the budget.
    """
    ori_nodes = image_to_nodes(original_channel, graph)
    delta_nodes = nodes - ori_nodes
    if channel == "H":
        delta_nodes = (delta_nodes + 0.5).remainder(1.0) - 0.5

    h, w = graph.image_hw
    folded_delta = F.fold(
        delta_nodes.t().unsqueeze(0),
        output_size=(h, w),
        kernel_size=graph.patch_size,
        stride=graph.stride,
    ).squeeze(0)
    coverage = graph.counts > 0
    avg_delta = folded_delta / graph.counts.clamp_min(1.0)
    if channel == "H":
        recon = (original_channel + avg_delta).remainder(1.0)
    else:
        recon = (original_channel + avg_delta).clamp(0.0, 1.0)
    recon = torch.where(coverage, recon, original_channel)
    return torch.where(mask.unsqueeze(0), recon, original_channel)


def attack_one_channel(
    channel: str,
    x_ori_img: torch.Tensor,
    x_tar_img: torch.Tensor,
    mask_ori: torch.Tensor,
    mask_tar: torch.Tensor,
    graph: PatchGraph,
    cfg: CWSGConfig,
    style_extractor: Optional[VGGStyleExtractor] = None,
    target_style_feats: Optional[Sequence[torch.Tensor]] = None,
    img_size: int = 224,
    verbose: bool = True,
) -> Tuple[torch.Tensor, torch.Tensor, List[Dict[str, float]]]:
    x_ori_nodes = image_to_nodes(x_ori_img, graph).detach()
    x = x_ori_nodes.clone().requires_grad_(True)
    momentum = torch.zeros_like(x)
    trace: List[Dict[str, float]] = []

    for t in range(cfg.steps):
        eta_t = cfg.eta * (2.0 ** (-2.0 * t / cfg.steps))
        tv_now = cfg.tv_lambda * min(1.0, 2.0 * t / cfg.steps)

        filtered = chebyshev_propagate(x, graph.lambda_sparse, cfg.filter_order)
        responses = filtered.abs().mean(dim=1)
        loss_spec = -(graph.m * responses).mean()
        loss_tv = graph_tv_loss(x, graph.edge_index_unique)
        recon = reconstruct_foreground(x, graph, x_ori_img, mask_ori, channel)

        if channel == "H":
            loss_channel = circular_hue_loss(recon, x_tar_img, mask_ori, mask_tar)
            channel_weight = cfg.hue_weight
            channel_name = "hue"
        elif channel == "S":
            if style_extractor is None or target_style_feats is None:
                # Support no-style ablations and minimal tests without downloading VGG.
                loss_channel = recon.sum() * 0.0
            else:
                adv_vgg = masked_saturation_for_vgg(recon, mask_ori, img_size)
                feats_adv = style_extractor(adv_vgg)
                loss_channel = style_loss(feats_adv, target_style_feats)
            channel_weight = cfg.style_weight
            channel_name = "style"
        elif channel == "V":
            loss_channel = masked_frequency_loss(recon, x_tar_img, mask_ori, mask_tar)
            channel_weight = cfg.freq_weight
            channel_name = "freq"
        else:
            raise ValueError(f"Unknown channel: {channel}")

        loss = loss_spec + tv_now * loss_tv + channel_weight * loss_channel
        loss.backward()

        with torch.no_grad():
            grad = x.grad * graph.w.view(-1, 1)
            momentum.mul_(cfg.gamma).add_(grad / (grad.abs().mean() + cfg.grad_eps))
            x.copy_(project_nodes(x - eta_t * torch.sign(momentum), x_ori_nodes, cfg.eps, channel))
            x.grad.zero_()

        trace.append(
            {
                "step": float(t + 1),
                "loss": float(loss.detach().cpu()),
                "spec": float(loss_spec.detach().cpu()),
                "tv": float(loss_tv.detach().cpu()),
                channel_name: float(loss_channel.detach().cpu()),
                "eta": float(eta_t),
                "tv_lambda": float(tv_now),
            }
        )
        if verbose and ((t + 1) % 5 == 0 or t == 0 or t + 1 == cfg.steps):
            print(
                f"[{channel} {t + 1:02d}/{cfg.steps}] loss={trace[-1]['loss']:.6f}, "
                f"spec={trace[-1]['spec']:.6f}, tv={trace[-1]['tv']:.6f}, "
                f"{channel_name}={trace[-1][channel_name]:.6f}"
            )

    final_channel = reconstruct_foreground(x.detach(), graph, x_ori_img, mask_ori, channel)
    return final_channel, x_ori_nodes, trace


@torch.no_grad()
def prepare_target_style_features(
    s_tar: torch.Tensor,
    mask_tar: torch.Tensor,
    extractor: VGGStyleExtractor,
    img_size: int,
) -> Sequence[torch.Tensor]:
    return extractor(masked_saturation_for_vgg(s_tar, mask_tar, img_size))


def cwsg_attack(
    img: torch.Tensor,
    target_img: torch.Tensor,
    mask_ori: torch.Tensor,
    mask_tar: torch.Tensor,
    cfg: CWSGConfig,
    device: torch.device,
    img_size: int = 224,
    verbose: bool = True,
) -> Tuple[torch.Tensor, Dict[str, torch.Tensor], Dict[str, List[Dict[str, float]]], PatchGraph]:
    hsv_ori = rgb_to_hsv(img).to(device)
    hsv_tar = rgb_to_hsv(target_img).to(device)

    # The graph is identical across channels because the mask and patch grid are shared.
    graph, mask_ori = build_patch_graph(hsv_ori[0:1], mask_ori, cfg, device)

    style_extractor: Optional[VGGStyleExtractor] = None
    target_style_feats: Optional[Sequence[torch.Tensor]] = None
    if cfg.style_weight != 0:
        style_extractor = VGGStyleExtractor(device)
        target_style_feats = prepare_target_style_features(
            hsv_tar[1:2], mask_tar, style_extractor, img_size
        )

    traces: Dict[str, List[Dict[str, float]]] = {}
    adv_channels: Dict[str, torch.Tensor] = {}
    for idx, channel in enumerate(("H", "S", "V")):
        if verbose:
            print(f"\n===== CWSG optimization on {channel} channel =====")
        adv_c, _, trace = attack_one_channel(
            channel=channel,
            x_ori_img=hsv_ori[idx : idx + 1],
            x_tar_img=hsv_tar[idx : idx + 1],
            mask_ori=mask_ori,
            mask_tar=mask_tar,
            graph=graph,
            cfg=cfg,
            style_extractor=style_extractor,
            target_style_feats=target_style_feats,
            img_size=img_size,
            verbose=verbose,
        )
        adv_channels[channel] = adv_c
        traces[channel] = trace

    hsv_adv = torch.cat([adv_channels["H"], adv_channels["S"], adv_channels["V"]], dim=0)
    rgb_adv = hsv_to_rgb(hsv_adv).clamp(0, 1)
    perturbations = {
        "H": (adv_channels["H"] - hsv_ori[0:1]).squeeze(0),
        "S": (adv_channels["S"] - hsv_ori[1:2]).squeeze(0),
        "V": (adv_channels["V"] - hsv_ori[2:3]).squeeze(0),
        "RGB": rgb_adv - img,
    }
    return rgb_adv, perturbations, traces, graph


def _build_victim(name: str, device: torch.device) -> nn.Module:
    name = name.lower()
    if name == "resnet50":
        return torchvision.models.resnet50(weights="IMAGENET1K_V1").to(device).eval()
    if name == "vgg16":
        return torchvision.models.vgg16(weights="IMAGENET1K_V1").to(device).eval()
    if name == "vit_b_16":
        return torchvision.models.vit_b_16(weights="IMAGENET1K_V1").to(device).eval()
    raise ValueError(f"Unsupported victim '{name}'. Choose from resnet50, vgg16, vit_b_16.")


@torch.no_grad()
def predict_with_victim(
    img: torch.Tensor,
    model_name: str,
    device: torch.device,
) -> Tuple[int, float]:
    model = _build_victim(model_name, device)
    normalize = transforms.Normalize(
        mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]
    )
    logits = model(normalize(img).unsqueeze(0))
    prob = torch.softmax(logits, dim=1)
    conf, pred = prob.max(dim=1)
    return int(pred.item()), float(conf.item())


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="CWSG black-box adversarial attack")
    parser.add_argument("--img", type=str, required=True, help="Path to the source image")
    parser.add_argument("--target_img", type=str, required=True, help="Path to the guidance image")
    parser.add_argument("--out_dir", type=str, default="cwsg_outputs")
    parser.add_argument("--img_size", type=int, default=224)
    parser.add_argument("--patch_size", type=int, default=8)
    parser.add_argument("--stride", type=int, default=4)
    parser.add_argument("--steps", type=int, default=20)
    parser.add_argument("--eps", type=float, default=8.0 / 255.0)
    parser.add_argument("--eta", type=float, default=0.1)
    parser.add_argument("--gamma", type=float, default=1.0)
    parser.add_argument("--tv_lambda", type=float, default=0.2)
    parser.add_argument("--filter_order", type=int, default=2)
    parser.add_argument("--rho", type=float, default=0.3)
    parser.add_argument("--background_weight", type=float, default=0.2)
    parser.add_argument("--mask_patch_threshold", type=float, default=0.4)
    parser.add_argument("--detector_conf", type=float, default=0.5)
    parser.add_argument("--mask_bin_threshold", type=float, default=0.5)
    parser.add_argument("--hue_weight", type=float, default=1.0)
    parser.add_argument("--style_weight", type=float, default=1.0)
    parser.add_argument("--freq_weight", type=float, default=1.0)
    parser.add_argument("--approx_centrality_k", type=int, default=None)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--quiet", action="store_true")
    parser.add_argument("--evaluate", action="store_true", help="Evaluate optional torchvision victims")
    parser.add_argument(
        "--victims",
        type=str,
        nargs="*",
        default=["resnet50", "vgg16"],
        choices=["resnet50", "vgg16", "vit_b_16"],
    )
    return parser.parse_args()


def config_from_args(args: argparse.Namespace) -> CWSGConfig:
    return CWSGConfig(
        patch_size=args.patch_size,
        stride=args.stride,
        steps=args.steps,
        eps=args.eps,
        eta=args.eta,
        gamma=args.gamma,
        tv_lambda=args.tv_lambda,
        filter_order=args.filter_order,
        rho=args.rho,
        background_weight=args.background_weight,
        mask_patch_threshold=args.mask_patch_threshold,
        hue_weight=args.hue_weight,
        style_weight=args.style_weight,
        freq_weight=args.freq_weight,
        approx_centrality_k=args.approx_centrality_k,
        seed=args.seed,
    )


def main() -> None:
    args = parse_args()
    set_seed(args.seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    print(f"Device: {device}")
    print(f"Output directory: {out_dir}")

    img = load_image(args.img, args.img_size, device)
    target_img = load_image(args.target_img, args.img_size, device)
    mask_ori = get_primary_foreground_mask(
        img, device, args.detector_conf, args.mask_bin_threshold
    )
    mask_tar = get_primary_foreground_mask(
        target_img, device, args.detector_conf, args.mask_bin_threshold
    )

    cfg = config_from_args(args)
    adv_img, perturbations, traces, graph = cwsg_attack(
        img=img,
        target_img=target_img,
        mask_ori=mask_ori,
        mask_tar=mask_tar,
        cfg=cfg,
        device=device,
        img_size=args.img_size,
        verbose=not args.quiet,
    )

    save_tensor_image(img, out_dir / "source.png")
    save_tensor_image(target_img, out_dir / "guidance.png")
    save_tensor_image(adv_img, out_dir / "cwsg_adv.png")
    save_comparison(
        [img, target_img, adv_img],
        ["Source", "Guidance", "CWSG adversarial"],
        out_dir / "comparison.png",
    )
    save_heatmap(mask_ori.cpu().numpy().astype(np.float32), "Source foreground mask", out_dir / "source_mask.png")
    save_heatmap(mask_tar.cpu().numpy().astype(np.float32), "Guidance foreground mask", out_dir / "guidance_mask.png")
    for name in ("H", "S", "V"):
        save_heatmap(
            perturbations[name].abs().cpu().numpy(),
            f"{name}-channel perturbation",
            out_dir / f"perturbation_{name}.png",
        )

    with open(out_dir / "loss_trace.json", "w", encoding="utf-8") as f:
        json.dump({"config": asdict(cfg), "traces": traces}, f, indent=2)
    with open(out_dir / "graph_summary.json", "w", encoding="utf-8") as f:
        json.dump(
            {
                "nodes": graph.n_nodes,
                "edges": int(graph.edge_index_unique.shape[1]),
                "key_nodes": int((graph.m == 1.0).sum().item()),
                "rho": cfg.rho,
                "patch_size": cfg.patch_size,
                "stride": cfg.stride,
            },
            f,
            indent=2,
        )

    if args.evaluate:
        print("\nVictim predictions:")
        for victim in args.victims:
            clean_pred, clean_conf = predict_with_victim(img, victim, device)
            adv_pred, adv_conf = predict_with_victim(adv_img, victim, device)
            print(
                f"  {victim}: clean={clean_pred} ({clean_conf:.4f}) -> "
                f"adv={adv_pred} ({adv_conf:.4f})"
            )

    print(f"\nSaved adversarial image and diagnostics to: {out_dir}")


if __name__ == "__main__":
    main()
